
CREATE TABLE `item_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `item_type` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


CREATE TABLE `item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `item_name` varchar(300) NOT NULL,
  `item_type` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `request` (
  `id` int NOT NULL AUTO_INCREMENT,
  `requested_by` varchar(300) NOT NULL,
  `requested_on` date DEFAULT NULL,
  `items` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `summary` (
  `req_id` int NOT NULL AUTO_INCREMENT,
  `requested_by` varchar(45) NOT NULL,
  `items` text NOT NULL,
  PRIMARY KEY (`req_id`),
  UNIQUE KEY `requested_by_UNIQUE` (`requested_by`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


/*
-- Query: SELECT * FROM cisco.item_type
LIMIT 0, 1000

-- Date: 2024-03-26 09:47
*/
INSERT INTO `` (`id`,`item_type`) VALUES (1,'Office Supply');
INSERT INTO `` (`id`,`item_type`) VALUES (2,'Equipment');
INSERT INTO `` (`id`,`item_type`) VALUES (3,'Furniture');

/*
-- Query: SELECT * FROM cisco.item
LIMIT 0, 1000

-- Date: 2024-03-26 09:45
*/
INSERT INTO `` (`id`,`item_name`,`item_type`) VALUES (1,'Pen',1);
INSERT INTO `` (`id`,`item_name`,`item_type`) VALUES (2,'Printer',2);
INSERT INTO `` (`id`,`item_name`,`item_type`) VALUES (3,'Marker',1);
INSERT INTO `` (`id`,`item_name`,`item_type`) VALUES (4,'Scanner',1);
INSERT INTO `` (`id`,`item_name`,`item_type`) VALUES (5,'Clear Tape',1);
INSERT INTO `` (`id`,`item_name`,`item_type`) VALUES (6,'Standing Table',2);
INSERT INTO `` (`id`,`item_name`,`item_type`) VALUES (7,'Shredder',2);
INSERT INTO `` (`id`,`item_name`,`item_type`) VALUES (8,'Thumbtack',1);
INSERT INTO `` (`id`,`item_name`,`item_type`) VALUES (10,'Paper Clip',1);
INSERT INTO `` (`id`,`item_name`,`item_type`) VALUES (11,'A4 Sheet',1);
INSERT INTO `` (`id`,`item_name`,`item_type`) VALUES (12,'Notebook',3);
INSERT INTO `` (`id`,`item_name`,`item_type`) VALUES (13,'Chair',3);
INSERT INTO `` (`id`,`item_name`,`item_type`) VALUES (14,'Stool',3);


/*
-- Query: SELECT * FROM cisco.request
LIMIT 0, 1000

-- Date: 2024-03-26 09:49
*/
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (1,'maya','2023-04-01','1,5,3');
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (2,'kie','2023-04-03','2');
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (3,'ron','2024-03-26','3');
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (4,'maya','2023-04-20','4');
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (5,'john','2023-05-01','5, 12');
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (6,'smith','2023-05-04','6');
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (7,'john','2023-05-10','7');
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (8,'lily','2023-05-11','8, 11');
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (9,'lily','2023-05-11','7');
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (10,'lily','2023-05-11','13');
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (11,'maya','2023-05-11','2');
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (12,'lily','2023-05-11','14');
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (43,'tina','2024-03-25','2,6');
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (44,'sumit','2024-03-25','1,4');
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (45,'sumit','2024-03-25','1,4');
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (46,'sumit','2024-03-25','1,3');
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (47,'sumit','2024-03-25','1,4');
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (48,'sumit','2024-03-25','1');
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (49,'sumit','2024-03-25','10');
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (50,'sumitk','2024-03-25','1');
INSERT INTO `` (`id`,`requested_by`,`requested_on`,`items`) VALUES (51,'sumit','2024-03-25','1');


/*
-- Query: SELECT * FROM cisco.summary
LIMIT 0, 1000

-- Date: 2024-03-26 09:51
*/
INSERT INTO `` (`req_id`,`requested_by`,`items`) VALUES (1,'tina','[{2,[2,6,]}]');
INSERT INTO `` (`req_id`,`requested_by`,`items`) VALUES (2,'sumit','[{1,[1,3,4]},{1,[1,3,4]},{1,[1,4]},{1,[1,4]},{1,[1,3]},{1,[1,4]},{1,[1]},{1,[10]},{1,[1]}]');
INSERT INTO `` (`req_id`,`requested_by`,`items`) VALUES (3,'sumitk','[{1,[1]}]');
INSERT INTO `` (`req_id`,`requested_by`,`items`) VALUES (4,'ron','[{1,[3]}]');
