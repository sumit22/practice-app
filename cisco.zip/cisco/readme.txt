how to install:

1. Unzip the directory
2. Move the unzipped folder to the webroot directory of your Apache webserver
3. Open the browser and navigate to localhost:80/cisco the screen for request creation and listing will open as described in UI sample in the instructions document. At this time no data will load.

CREATE DB and run migrations/seeders

1. open your DBMS client applicaion like MySQL Workbench.
2. create a new database named `cisco` using command 
    CREATE database cisco;
3. change database to cisco
4. RUN the script from migrations.sql file present in the project directory. This will create all the required tables and seed some dummy data provided with the instructions file of the assignment

NOTE: the during development it was assumed that DB server (MySQL) is running locally on port 3306 with username=root and password=root as per the below DSN string
$dsn = "mysql:host=localhost;port=3306;dbname=cisco;charset=utf8mb4";
In case these variables are different please make required changes in class ORM defined in the app.php file where DSN string is defined.

go back to the browser and refresh the page which was opened earlier, now the page should show all the seeded requests

creation of new request
Click on the button labelled `Add Request`, A popup modal will open with the form to provide necessary details for the request
click on submmit after filling the form, and refresh the page, new request should be present in the last page

Editing of the request:
in the requests table, each row has an edit button to edit the corresponding request, on clicking this button a form similar to request creation form will open, where details of the request can be changed.
for example user can change the user name, items in the request can be modified, removed or new items can be added. once done, click on update request button to submit the form.