let items = [];

function getFormDataAsJson(form) {
    const formData = new FormData(form);
    const jsonData = {};

    for (let [key, value] of formData.entries()) {
        // Check if key already exists in JSON object
        if (jsonData.hasOwnProperty(key)) {
            // If key is already an array, push the value to it
            if (Array.isArray(jsonData[key])) {
                jsonData[key].push(value);
            } else {
                // If key is not an array yet, convert it to an array and push both values
                jsonData[key] = [jsonData[key], value];
            }
        } else {
            // If key does not exist yet, simply add it to JSON object
            jsonData[key] = value;
        }
    }

    return jsonData;
}

$(document).ready(function () {

    const requestsTableId = 'dataTable-requests';

    let requestDataTable = $('#' + requestsTableId).dataTable({
        columns: [
            { data: 'user' },
            { data: 'items' },
            { data: 'item_type' },
            {
                render: (data, type, row) => {

                    return `<button data-id="${row.id}" class="btn btn-primary edit-request" >Edit</button>`
                }
            }
        ],

        ajax: {
            method: 'GET',
            url: '/cisco/app.php?requested-page=get-all-requests'
        },
        processing: true,
        serverSide: true,
        dom: "Bfrtip",
        buttons: [
            {
                text: "Add Request",
                className: "btn btn-primary",
                action: function (e, dt, node, config) {
                    createRequest();
                }
            }
        ]
    });


    //handle editing of request in a popup
    $("#dataTable-requests tbody").on('click', 'button', function (e) {
        e.preventDefault();
        console.log('Edit button clicked')

        const btn = $(this);
        const requestId = btn.attr('data-id');
        console.log(requestId);

        //staticBackdropEdit
        let requestEditorModal = new bootstrap.Modal(document.getElementById('staticBackdropEdit'));



        //fetch request details from the server to edit
        $.ajax({
            method: "GET",
            url: '/cisco/app.php?requested-page=get-request-by-id',
            dataType: "JSON",
            data: { id: requestId },
            statusCode: {
                200: function (requestObject, textStatus, jqXHR) {
                    console.log(requestObject); //request object

                    $.ajax({
                        method: "GET",
                        url: '/cisco/app.php?requested-page=get-all-items',
                        dataType: "JSON",
                        success: (xhr, data) => {

                            const requestedBy = requestObject.requested_by
                            const items = requestObject.items.split(',')
                            const requestId = requestObject.id

                            console.log('items in request', items);

                            let formBodyContainer = $('#EditFormControlsHolder')
                            //user-edit, request-id
                            $('#user-edit', formBodyContainer).val(requestedBy)
                            $('#request-id', formBodyContainer).val(requestId)
                            let itemCounter = 0;
                            for (const itemId of items) {

                                let itemOptions = `<option value="">Select Item</option>`;
                                for (const item in xhr) {
                                    let selected = ''
                                    if (itemId.trim() == item) {
                                        selected = 'selected'
                                    }
                                    itemOptions += `<option ${selected} class="item-options item-options-type-${xhr[item]['item_type']}" 
                                    data-itype="${xhr[item]['item_type']}" value="${item}">${xhr[item]['item_name']}</option>`;
                                }

                                let itemDropDown = $('#dropDownHolder').children(':first').clone();
                                $('.fetch-items', itemDropDown).html(itemOptions)
                                formBodyContainer.append(itemDropDown);

                                itemCounter++;
                            }
                            requestEditorModal.show();
                        }
                    });

                }
            }
        });
    });

    $('#staticBackdropEdit').on('change', ".fetch-items", function (e) {
        let _this = $(this);
        const selectedValue = _this.val()
        if (selectedValue != '') {
            $('.add-item-row', _this.parent().parent()).show();
            if ($(".fetch-items").length == 1) {
                //const selectedItemClass = 

            }
        } else {
            $('.add-item-row', _this.parent().parent()).hide();
        }
    })

    $('#staticBackdropEdit,#staticBackdrop').on('click', '.add-item-row', function (e) {

        let toClone = $(this).parent().parent();
        if ($(".fetch-items", toClone).val() == '') {
            alert("select item to proceed");
            return;
        }
        let container = toClone.parent();
        const newRow = toClone.clone();
        $('.remove-item-row', newRow).show();
        $('.fetch-items', newRow).val('')
        container.append(newRow);
    });

    $('#staticBackdrop,#staticBackdropEdit').on('click', '.remove-item-row', function (e) {
        $(this).parent().parent().remove();
    })

    /**
     * handler for creation of request
     * UI features
     */
    function createRequest() {
        let reqModal = new bootstrap.Modal(document.getElementById('staticBackdrop'));

        //first fetch all items for populating items dropdown
        $.ajax({
            method: "GET",
            url: '/cisco/app.php?requested-page=get-all-items',
            dataType: "JSON",
            success: (xhr, data) => {
                let itemDropDown = $('#dropDownHolder').children(':first').clone();
                let itemOptions = `<option value="">Select Item</option>`;
                for (const item in xhr) {
                    let selected = ''
                    itemOptions += `<option ${selected} class="item-options item-options-type-${xhr[item]['item_type']}" 
                                    data-itype="${xhr[item]['item_type']}" value="${item}">${xhr[item]['item_name']}</option>`;
                }
                $('.fetch-items', itemDropDown).html(itemOptions)
                //CreateFieldHolder
                let formBodyContainer = $('.CreateFieldHolder')
                formBodyContainer.append(itemDropDown);
                $('.add-item-row', itemDropDown).hide();


                $('#staticBackdrop').on('change', ".fetch-items", function (e) {
                    let _this = $(this);
                    const selectedValue = _this.val()
                    if (selectedValue != '') {
                        $('.add-item-row', _this.parent().parent()).show();
                        if ($(".fetch-items").length == 1) {
                            //const selectedItemClass = 

                        }
                    } else {
                        $('.add-item-row', _this.parent().parent()).hide();
                    }
                })



                if ($('.remove-item-row', $('#staticBackdrop')).length == 1) {
                    $('.remove-item-row', $('#staticBackdrop')).hide();
                }

                reqModal.show();
            }
        });



        $('.create-request-submit').on('click', function (e) {

            const form = document.getElementById('CreateRequestForm');
            const formData = getFormDataAsJson(form);
            $.ajax({
                method: "POST",
                dataType: "JSON",
                data: formData,
                url: '/cisco/app.php?requested-page=create-new-request',
                statusCode: {
                    201: function (responseObject, textStatus, jqXHR) {
                        console.log(responseObject, textStatus, jqXHR);
                        alert(responseObject.message);
                        window.location.reload();
                    },
                    400: function (responseObject, textStatus, jqXHR) {
                        alert(responseObject.responseJSON.message);
                    }
                    //similarly other error cases can handled
                }
            });

        })


        

        $("#staticBackdrop").on("hidden.bs.modal", function () {

            $('.item-dropdown', $("#staticBackdrop")).remove();
        });


    }


    $('.edit-request-submit').on('click', function (e) {

        const form = document.getElementById('EditRequestForm');
        const formData = getFormDataAsJson(form);

        console.log(formData)
        $.ajax({
            method: "POST",
            dataType: "JSON",
            data: formData,
            url: '/cisco/app.php?requested-page=edit-old-request',
            statusCode: {
                200: function (responseObject, textStatus, jqXHR) {
                    console.log(responseObject, textStatus, jqXHR);
                    alert(responseObject.message);
                    window.location.reload();
                },
                400: function (responseObject, textStatus, jqXHR) {
                    alert(responseObject.responseJSON.message);
                }
            }
        });

    })



    $("#staticBackdropEdit").on("hidden.bs.modal", function () {
        $('.item-dropdown', $("#staticBackdropEdit")).remove();
    });
});