<?php


/**
 * a simple ORM layer to represtnt DB tables as classes
 */
class ORM
{
    protected $tableName = '';
    protected $primaryKeyCol = 'id';
    protected $pdo;

    public function __construct($tableName = '')
    {
        if ($tableName != '') {

            $this->tableName = $tableName;
        }
        // Initialize PDO connection
        $dsn = "mysql:host=localhost;port=3306;dbname=cisco;charset=utf8mb4";
        $username = "root";
        $password = "root";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $this->pdo = new PDO($dsn, $username, $password, $options);
        } catch (PDOException $e) {
            throw new PDOException($e->getMessage(), (int)$e->getCode());
        }
    }

    public function create($data)
    {
        $keys = implode(', ', array_keys($data));
        $values = implode(', :', array_keys($data));
        $sql = "INSERT INTO $this->tableName ($keys) VALUES (:$values)";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute($this->prepareData($data));
    }

    public function find($id)
    {
        $sql = "SELECT * FROM $this->tableName WHERE {$this->primaryKeyCol} = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }

    public function all()
    {
        try {
            $sql = "SELECT * FROM {$this->tableName}";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $result;
        } catch (\Exception $e) {
        }
    }

    public function update($id, $data)
    {
        $set = '';
        foreach ($data as $key => $value) {
            $set .= "$key = :$key, ";
        }
        $set = rtrim($set, ', ');
        $data['id'] = $id;
        $sql = "UPDATE $this->tableName SET $set WHERE {$this->primaryKeyCol} = :id";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute($this->prepareData($data));
    }

    public function delete($id)
    {
        $sql = "DELETE FROM $this->tableName WHERE {$this->primaryKeyCol} = :id";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute(['id' => $id]);
    }

    protected function prepareData($data)
    {
        foreach ($data as $key => $value) {
            if (is_array($value) || is_object($value)) {
                $data[$key] = json_encode($value);
            }
        }
        return $data;
    }

    public function __destruct()
    {
        // Close PDO connection
        $this->pdo = null;
    }

    public function getPdo()
    {
        return $this->pdo;
    }
}

class Item extends ORM
{
    protected $tableName = 'item';

    public function getItemCategoriesByItems(array $items)
    {
        //create variable placeholder string, as per length of the array
        $itemsPlaceholders = implode(',', array_fill(0, count($items), '?'));
        $sql = "SELECT item_type from item WHERE id IN ($itemsPlaceholders) group by item_type";


        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($items);

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }
}

class Request extends ORM
{
    protected $tableName = 'request';

    public function getPaginatedRequests($offset = 0, $limit = 10)
    {

        $countQuery = "SELECT count(*) as count from request";
        $stmt = $this->pdo->prepare($countQuery);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        $count = $result['count'];


        $sql = "SELECT * from request limit {$offset}, {$limit}";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return [$count, $result];
    }


    public function createNewRquest($user, $items)
    {
        $itemTypes = (new Item())->getItemCategoriesByItems($items);

        if (count($itemTypes) !== 1) {
            throw new \Exception("Please enter items of only one type in one request", 400);
        }

        $itemTypeRequested = $itemTypes[0]['item_type'];

        $requestTableData = [
            'requested_by' => $user,
            'items' => implode(',', $items),
            'requested_on' => date('Y-m-d')
        ];

        $this->create($requestTableData);

        //make entries in summary table

        $summary = (new Summary())->createOrUpdateSummary($requestTableData, $itemTypeRequested);
    }

    public function updateRequest($id, $user, $items){
        //find request
        $request = $this->find($id);
        if(!$request) {
            throw new \Exception("Invalid request ID", 400);
        }

        $itemTypes = (new Item())->getItemCategoriesByItems($items);

        if (count($itemTypes) !== 1) {
            throw new \Exception("Please enter items of only one type in one request", 400);
        }

        $itemTypeRequested = $itemTypes[0]['item_type'];

        $requestTableData = [
            'requested_by' => $user,
            'items' => implode(',', $items),
            'requested_on' => date('Y-m-d')
        ];
        //DB transaction should be used
        $this->update($id, $requestTableData);
        $summary = (new Summary())->createOrUpdateSummary($requestTableData, $itemTypeRequested);
    }
}

class Summary extends ORM
{
    protected $tableName = 'summary';
    protected $primaryKeyCol = 'req_id';

    public function createOrUpdateSummary(array $requestData, $itemTypeRequested)
    {
        
        //echo 'SUMMARY';
        $requestedBy = $requestData['requested_by'];
        //check if records exists for this user in summary table
        $sql = "SELECT * FROM {$this->tableName} WHERE requested_by = ?";


        $stmt = $this->pdo->prepare($sql);

        //merge all params
        $qParams = [$requestedBy];

        $stmt->execute($qParams);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if(!$result) {
            //no existing entries found

            $summaryRow = [
                'requested_by'=>$requestedBy,
                'items'=> $this->createSummaryItemFormat($requestData['items'], $itemTypeRequested)
                ];
            $this->create($summaryRow);
        } else {

            $items = $this->createSummaryItemFormat($requestData['items'],$itemTypeRequested, $result['items']);

            $this->update($result['req_id'],[
                'items'=>$items
            ]);

        }
    }

    /**
     * [{1,[1,5,3]}, {2,[4,2]}] 
     * [{[{2,[2,6]}],[2,6]}]

     */
    private function createSummaryItemFormat($newItems, $newItemType, $oldSummary='[]'){
        $newEntryString = "{{$newItemType},[{$newItems}]}";

        if($oldSummary=='[]'){
            $updatedSummary = '[' . $newEntryString . ']';
        } else {
            $updatedSummary = rtrim($oldSummary, $oldSummary[-1]) . ',' . $newEntryString . ']';
        }

        return $updatedSummary;
    }
}

class User extends ORM
{
    protected $tableName = 'user';
}

class ItemType extends ORM
{
    protected $tableName = 'item_type';
}

//basic routing goes here

$requestMethod = $_SERVER['REQUEST_METHOD'];

$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, true);
$requestURI = $_SERVER['REQUEST_URI'];
$requestedPage = $_REQUEST['requested-page'] ?? '';
$requestHandler = new Controller();
switch ($requestMethod) {
    case 'GET': {
            //handle all GET REQUESTS

            switch ($requestedPage) {
                case 'get-all-requests': {

                        return $requestHandler->getAllRequests($_REQUEST);
                        break;
                    }

                case 'get-all-users': {
                        return $requestHandler->getAllUsers();
                        break;
                    }

                case 'get-all-items': {
                        return $requestHandler->getAllItemsMap();
                        break;
                    }
                case 'get-request-by-id' : {
                    return $requestHandler->getRequestDetailsById($_REQUEST['id']);
                    break;
                }
            }
            break;
        }
    case 'POST': {
            //handle all POST REQUESTS

            switch ($requestedPage) {
                case 'create-new-request': {

                        return $requestHandler->createNewRequest($_REQUEST);
                        break;
                    }
                case 'edit-old-request': {
                        return $requestHandler->editOldRequest($_REQUEST);
                        break;
                    }
            }
            break;
        }
    default:
        die("METHOD NOT SUPPORTED YET ON THIS SERVER");
}

//set up a basic controller/request handler

class Controller
{

    public function getAllItemsMap()
    {
        $itemCategories = (new ItemType())->all();
        $icMap = [];

        foreach ($itemCategories as $ic) {
            $icMap[$ic['id']] = $ic['item_type'];
        }
        $items = (new Item())->all();

        $itemsMap = [];

        foreach ($items as $item) {
            $itemsMap[$item['id']] = [
                'item_name' => $item['item_name'],
                'item_type_name' => $icMap[$item['item_type']],
                'item_type' => $item['item_type']
            ];
        }

        return JsonResponse::json($itemsMap, 200);
    }

    public function getAllRequests(array $req)
    {

        $itemCategories = (new ItemType())->all();
        $icMap = [];

        foreach ($itemCategories as $ic) {
            $icMap[$ic['id']] = $ic['item_type'];
        }
        $items = (new Item())->all();

        $itemsMap = [];


        foreach ($items as $item) {
            $itemsMap[$item['id']] = [
                'item_name' => $item['item_name'],
                'item_type' => $icMap[$item['item_type']]
            ];
        }



        $offset = $req['start'] ?? 0;
        $limit = $req['length'] ?? 10;
        $requests = (new Request())->getPaginatedRequests($offset, $limit);

        $count = $requests[0];
        $requests = $requests[1];

        $out = [];

        foreach ($requests as $request) {

            $outTemp = [
                'id' => $request['id'],
                'user' => $request['requested_by']
            ];

            $itemIds = explode(',', $request['items']);

            $itemNames = [];
            $itemType = '';

            foreach ($itemIds as $itemId) {
                $itemDetail = $itemsMap[trim($itemId)];
                $itemNames[] = $itemDetail['item_name'];

                $itemType = $itemDetail['item_type'];
            }
            $outTemp['items'] = implode(', ', $itemNames);
            $outTemp['item_type'] = $itemType;

            $out[] = $outTemp;
        }
        $dataTableResponse = [
            'draw' => $req['draw'],
            'recordsTotal' => $count,
            'recordsFiltered' => $count,
            'data' => $out
        ];

        return JsonResponse::json($dataTableResponse, 200);
    }

    public function getRequestDetailsById($id){

        $requestDetail = (new Request())->find($id);


        JsonResponse::json($requestDetail);


    }

    public function getAllUsers()
    {
        return JsonResponse::json((new User())->all(), 200);
    }

    public function getItemCategories()
    {
    }
    public function createNewRequest($req)
    {
        $user = $req['user'] ?? null;
        if (!$user) {
            JsonResponse::error('Please enter name of the user', 400);
        }
        $items = $req['items'] ?? [];
        if (count($items) == 0) {
            JsonResponse::error('Please select items for inventory', 400);
        }

        try{
            $responseData = (new Request())->createNewRquest($user, $items);
            JsonResponse::json([
                'message'=>"request created"
            ], 201);
        }catch(\Exception $e){
            JsonResponse::error($e->getMessage(), $e->getCode());
        }
        
    }
    public function editOldRequest($req)
    {
        $requestId = $req['request_id'];
        if(!$requestId) {
            return JsonResponse::error('Invalid Request ID provided', 400);
        }

        $user = $req['user'] ?? null;
        if(!$user) {
            return JsonResponse::error('Invalid User provided', 400);
        }
        $items = $req['items'] ?? [];
        if (count($items) == 0) {
            JsonResponse::error('Please select items for inventory', 400);
        }

        try{
            $responseData = (new Request())->updateRequest($requestId,$user, $items);
            return JsonResponse::json([
                'message'=>"request updated"
            ], 200);
        }catch(\Exception $e){
            return JsonResponse::error($e->getMessage(), $e->getCode());
        }
    }
}


/**
 * Class JsonResponse
 * Utility class to send json responses
 */
class JsonResponse
{

    /**
     * SEND a JSON response to client
     * 
     * @param $response
     * @param int $statusCode
     */
    public static function json(array $response, int $statusCode = 200): void
    {
        header('Content-Type: application/json');
        http_response_code($statusCode);
        echo json_encode($response);
    }

    /**
     * send error response in JSON format
     */
    public static function error(string $message, int $statusCode = 500): void
    {
        static::json([
            "status" => $statusCode,
            "message" => $message
        ], $statusCode);
    }
}
